import javax.swing.JFrame;
import javax.swing.JLabel;
import java.util.concurrent.*;

public class Exerc3 implements Runnable {
	protected Monitor m;
	protected int i ;

	public Exerc3( Monitor m, int i ) {
		this.m = m;
		this.i = i;
	}

	public void run () {
		String myname = Thread.currentThread().getName();
		JFrame f = new JFrame(myname);
		JLabel l = new JLabel ( "#" );

		f.add( l ) ;
		f.setSize(150, 200);
		f.setLocation( i * 200, 100 );
		f.setVisible( true );

//		synchronized( m ) {	// o método espera já está declarado como synchronized
		do {
			m.espera();	// main thread deve executar "accordaTodas()" depois de todos os threads executarem "espera()"
		} while ( m.leVez() != i );
					// só um thread executa dentro do bloco - acesso exclusivo!
//		}

		for ( int i = 0; i < 20; i ++) {
			try {
				Thread.sleep( 100 );
			} catch ( InterruptedException ie ) {}

			l.setText( " " + l.getText( ) + "#" );
		}

		f.dispose();
	}

	public static void main( String args[] ) {
		Monitor mon = new Monitor();
		Thread [] ths = new Thread [5];	// 8

		for ( int i = 0; i < ths.length; i ++) {
			ths[i] = new Thread( new Exerc3( mon, i ), "Th" + i ) ;
			ths[i].start();
		}

		System.out.println( "[Main] All threads created!" );
		System.out.println( "[Main] Activating threads!" );

		try {
			Thread.sleep( 5 * 1000 );
		} catch ( InterruptedException ie ) {}
	
		for ( int i = 0; i < ths.length; i ++) {
//			synchronized( mon ) {
				mon.defineVez( i );
				mon.acordaTodas();
//			}

			try {
				Thread.sleep( 1 * 1000 );
			} catch ( InterruptedException ie ) {}
		}

		try {
			for ( int i = 0 ; i < ths.length; i++ ) {
				ths[i].join();
			}

		} catch ( InterruptedException ie) {}
			System.out.println( "[Main] All threads ended!" );
		
	}
}

