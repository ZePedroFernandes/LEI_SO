public class Exerc3Main {

	public static void main (String [] args) {
		final int end;

		if ( args.length != 1 ) {
			System.err.println( "Modo de uso: java Exerc3Main <número de segundos em espera>" );
			System.exit( 0 );
		}

		Thread print = new Thread( new Exerc3Sub(), "[Th0]" );

		try {
			print.start();
			Thread.sleep( Integer.parseInt( args[0] ) * 1000 );
			print.interrupt();

			// wait for threads to end
			print.join();
		} 
		catch( InterruptedException | IllegalThreadStateException | SecurityException | NumberFormatException e) { System.out.println("teste 2"); }
	}

}
